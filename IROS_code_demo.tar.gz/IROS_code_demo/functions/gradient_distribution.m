%-------------------------------------
function gd = gradient_distribution(imagePatch, m)
% This function creates a m bins histogram
% ....
% ....
%-------------------------------------
[h,w] = size(imagePatch);
center = round([h/2,w/2]);
normd = norm(center,2);
[imagefx, imagefy] = gradient(imagePatch);
% imagefx = double(imagefx)./max(max(imagefx));
% imagefy = double(imagefy)./max(max(imagefy));
imagefx = ceil(imagefx.*m);
imagefy = ceil(imagefy.*m);
imagefx(imagefx == 0) = 1;
imagefy(imagefy == 0) = 1;
for u = 1:2*m
    [row, col] = find(imagefx == u-m/2);
    distance = sqrt((row - center(1)).^2 + (col - center(2)).^2);
    distance = distance./normd;
    k = 2*pi.*(1-distance);
    gdx(u) = sum(k);
end

gdx = gdx./sum(gdx);

for u = 1:2*m
    [row, col] = find(imagefy == u-m/2);
    distance = sqrt((row - center(1)).^2 + (col - center(2)).^2);
    distance = distance./normd;
    k = 2*pi.*(1-distance);
    gdy(u) = sum(k);
end

gdy = gdy./sum(gdy);

gd = [gdx,gdy];

return