function new_rect = find_new_pos(xp,classS_index,rect,img_gray,StaticFeatures,ConfidenceFeatures,target_para)

n = size(classS_index);
target_size = rect(3:4);
new_rect = rect;
max_correspoundence = 0;

for i = 1:n
    center = xp(classS_index(i),:);
    rect(1:2) = center - rect(3:4)./2;
    rect(3:4) = target_size;
    rect = fix_rect(img_gray, rect);
    
    im_candidate = imcrop(img_gray,rect);
    
    mincontrast_para = target_para;
    candidate_corners = detectFASTFeatures(im_candidate, 'MinContrast', mincontrast_para);
    mincontrast_para = 0.2;
    while candidate_corners.Count < 50 && mincontrast_para > 0.05
        mincontrast_para = 0.8*mincontrast_para;
        candidate_corners = detectFASTFeatures(im_candidate, 'MinContrast', mincontrast_para);
    end
    
    candidate_corners.Location = candidate_corners.Location + repmat([rect(1)-1,rect(2)-1],candidate_corners.Count,1);
    
    [Candidate_Features, Candidate_Points] = extractFeatures(img_gray, candidate_corners);
    Candidate_Dictionary.Features = Candidate_Features.Features;
    Candidate_Dictionary.Location = Candidate_Points.Location;
    
    indexPairs1 = matchFeatures(StaticFeatures, Candidate_Features);
    indexPairs2 = matchFeatures(ConfidenceFeatures, Candidate_Features);
    n_correspoundence = 0.6*size(indexPairs1,1) + 0.4*size(indexPairs2,1);

    if n_correspoundence > max_correspoundence
        new_rect = rect;
        max_correspoundence = n_correspoundence;
        hold on;
        rectangle('Position',rect,'LineWidth',1,'EdgeColor','y');
        hold off;
    end
    
end

return