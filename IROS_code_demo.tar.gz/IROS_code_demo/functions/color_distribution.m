%-------------------------------------
function cd = color_distribution(imagePatch, m)
% This function creates a m bins histogram
% ....
% ....
%-------------------------------------
[h,w] = size(imagePatch);
center = round([h/2,w/2]);
normd = norm(center,2);
% imagePatch = double(imagePatch)./max(max(imagePatch));
imagePatch = ceil(imagePatch.*m);
imagePatch(imagePatch == 0) = 1;
for u = 1:m
    [row, col] = find(imagePatch == u);
    distance = sqrt((row - center(1)).^2 + (col - center(2)).^2);
    distance = distance./normd;
    k = 2*pi.*(1-distance);
    cd(u) = sum(k);
end

cd = cd./sum(cd);

return