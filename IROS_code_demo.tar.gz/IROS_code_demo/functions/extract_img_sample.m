%-------------------------------------
function feature_vector = extract_img_sample(I, c, w, h)
% This function extract an image patch in image I given the center and size of the ROI

VIDEO_WIDTH = size(I,2);
VIDEO_HEIGHT = size(I,1);

if VIDEO_HEIGHT - c(2) < 0.2*h
    c(2) = VIDEO_HEIGHT/2;
end

if VIDEO_WIDTH - c(1) < 0.2*w
    c(1) = VIDEO_WIDTH/2;
end

y = c(2)-h/2;
x = c(1)-w/2;

r2 = round(min(VIDEO_HEIGHT, y+h+1));
c2 = round(min(VIDEO_WIDTH, x+w+1));
r = round(max(y, 1));
c = round(max(x, 1));
rect = [ c, r, w-1, h-1 ];
impatch = imcrop(I, rect);
window = double(impatch)./256;
cd = color_distribution(window,32);
gd = gradient_distribution(window, 16);
feature_vector = [cd,gd];
% mincontrast_para = 0.2;
% corners = detectFASTFeatures(impatch, 'MinContrast', mincontrast_para);
% while corners.Count < 1 && mincontrast_para > 0.01
%     mincontrast_para = 0.8*mincontrast_para;
%     corners = detectFASTFeatures(impatch, 'MinContrast', mincontrast_para);
% end
% corners = corners.selectStrongest(1);
% corners.Location = corners.Location + [rect(1)-1,rect(2)-1];
% [feature, point] = extractFeatures(I, corners);
% % features = extractHOGFeatures(impatch);
% feature_vector = [cd,double(feature.Features)./256];
%-------------------------------------
return