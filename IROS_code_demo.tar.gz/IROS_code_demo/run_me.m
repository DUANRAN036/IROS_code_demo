%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demo of paper "Recoverable Recommended Keypoint-aware Visual Tracking
% Using Coupled-layer Appearance Modelling" Ran Duan, Changhong Fu, Erdal
% Kayacan. Singapore Technologies Engineering-NTU Corp Lab.
%
% The benchmark test code (without optimize)
%
% Folder "benchmark" contain all benchmark sequences
% Folder "initOmit" contain the frames that target is fully-occluded or out
% of view.
% Folder Results_TRE contain the tracking results of other trackers
% provided by the benchmark.
% The example of dataset Suv is given. Please add more sequences and
% related files to these folders for the benchmark test.
% Sequences and related files can be found in following link:
% https://sites.google.com/site/trackerbenchmark/benchmarks/v10
%
% 29-02-2016
% DUAN Ran
% At Nanyang Technological University
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% initialization
clc;
clear all;
close all;
warning('off','all');

% add other functions
addpath('./Ran_Voting_System');
addpath('./functions');
% read the datasets that to be tested
fdir = dir('./Results_TRE');
dataset_num = length(fdir);
% start testing
for dataset_count = 3:dataset_num
    
    dataset = fdir(dataset_count).name;
    
    %% init start frame
    database_folder = 'Results_TRE';
    dataset_folder = dataset;
    fulldir = fullfile(cd,database_folder,dataset_folder);
    addpath(fulldir);
    % copy the format of the benchmark test result
    res_dir = dir([fulldir,'/*_Frag.mat']);
    results = importdata(res_dir.name);
    experiment_iteration = length(results);
    
    %% read frame data
    database_folder = 'benchmark';
    dataset_folder = dataset;
    fulldir = fullfile(cd,database_folder,dataset_folder,'img');
    addpath(fulldir);
    img_dir = dir([fulldir,'/*.jpg']);
    
    for ex_iter = 1:experiment_iteration       
        %% select the object region       
        start_frame = results{1,ex_iter}.startFrame;
        
        figure(1);
        img = imread(img_dir(start_frame).name);
        imshow(img);
        % initial tracking bounding box
        rect = results{1,ex_iter}.anno(1,:);
        imPatch = imcrop(img,rect);
        
        rect_tracking = rect;   % feature extracting window
        rect_tracking_static = rect_tracking; % original window
        rect_tracking_confidence = rect_tracking; % confidence window
        
        %% initial feature extracting
        % conver image to gray image
        if size(img,3) > 1,
            img_gray = rgb2gray(img);
            im_target = rgb2gray(imPatch);
        else
            img_gray = img;
            im_target = imPatch;
        end
        % detecting features
        mincontrast_para = 0.2;
        target_corners = detectFASTFeatures(im_target, 'MinContrast', mincontrast_para);
        
        n = 50; % maximum number of features of target
        
        if target_corners.Count > 10 % shrink the region if there are too many features
            rect(1:2) = rect(1:2) + 0.2*rect(3:4);
            rect(3:4) = rect(3:4) - 0.4*rect(3:4);
            im_target = imcrop(img_gray,rect);
            target_corners = detectFASTFeatures(im_target, 'MinContrast', mincontrast_para);
        else % grow the region if no enough features
            rect(1:2) = rect(1:2) - 0.1*rect(3:4);
            rect(3:4) = rect(3:4) + 0.2*rect(3:4);
            im_target = imcrop(img_gray,rect);
            target_corners = detectFASTFeatures(im_target, 'MinContrast', mincontrast_para);
        end
        % keep detecting if still no enough features
        while target_corners.Count < n && mincontrast_para > 0.05
            mincontrast_para = 0.8*mincontrast_para;
            target_corners = detectFASTFeatures(im_target, 'MinContrast', mincontrast_para);
        end
        % grow the region if still no enough features
        searching_count = 1;
        while target_corners.Count < n/2 && searching_count < 20
            rect(1:2) = rect(1:2) - 0.05*rect(3:4);
            rect(3:4) = rect(3:4) + 0.1*rect(3:4);
            im_target = imcrop(img_gray,rect);
            target_corners = detectFASTFeatures(im_target, 'MinContrast', mincontrast_para);
            searching_count = searching_count + 1;
        end
        % record feature the extracting parameter
        target_para = mincontrast_para;
        % keep the top n features
        if target_corners.Count > n
            target_corners = target_corners.selectStrongest(n);
        end
        % recover feature coordinates
        target_corners.Location = target_corners.Location + repmat([rect(1)-1,rect(2)-1],target_corners.Count,1);
        % extracting features
        [Target_Features, Target_Points] = extractFeatures(img_gray, target_corners);
        % initial target information
        pos = [rect(1)+rect(3)/2 rect(2)+rect(4)/2 1];
        target_size = [rect(3), rect(4)];
        original_pos = pos;
        
        %% initial learning system
        
        Target_Dictionary.Features = Target_Features.Features;
        Target_Dictionary.Location = Target_Points.Location;
        dictionary_size = size(Target_Dictionary.Location,1);
        % static dictionary
        StaticFeatures = binaryFeatures(Target_Dictionary.Features);
        StaticPoints = Target_Points.Location;
        StaticSize = target_size;
        % confidence dictionary
        ConfidenceFeatures = StaticFeatures;
        ConfidencePoint = StaticPoints;
        ConfidenceSize = target_size;
        
        confidence_pos = pos;
        confidence_weight = 1;
        % initiial dictionary L
        dictionary_maximum_size = 400;
        feature_link_table = eye(dictionary_size);
        % tracking control parameters
        tform.T = eye(3);
        previous_tform.T = tform.T;
        minimum_trust_n_paris = n/2;
        reset_flag = 1;
        ranking = 100*ones(dictionary_size,3); % initial ranking score
        search_flag = 0;
        confidence_rank = ranking;
        static_rank = ranking;
        confidence_update_flag = 1;
        
        %% svm learning
        lost_flag = 0;
        hold on;
        rectangle('Position',rect_tracking_static,'LineWidth',1,'EdgeColor','b');
        hold off;
        rect_recover = rect_tracking_static;
        samples_size = rect_tracking_static(3:4);
        N_samples_positive = 100;
        N_samples_negative = 400;
        feature_vector_size = 32+32+32;
        train_data_positive = zeros(N_samples_positive,feature_vector_size);
        train_data_negative = zeros(N_samples_negative,feature_vector_size);
        data_label = [ones(N_samples_positive,1);zeros(N_samples_negative,1)];
        i = 1;
        j = 1;
        xmin = round(pos(1)-rect_recover(3)/3);
        xmax = round(pos(1)+rect_recover(3)/3);
        ymin = round(pos(2)-rect_recover(4)/3);
        ymax = round(pos(2)+rect_recover(4)/3);
        while i <= N_samples_positive
            sample = [randi([xmin,xmax],1),randi([ymin,ymax],1)];
            try
                train_data_positive(i,:) = extract_img_sample(img_gray,sample,samples_size(1),samples_size(2));
                i = i + 1;
                hold on;
                plot(sample(1), sample(2), 'g*');
                hold off;
            catch
            end
            
        end
        while j <= N_samples_negative
            [ymax,xmax] = size(img_gray);
            sample = [randi([1, xmax],1),randi([1,ymax],1)];
            sample_dist = abs(sample - pos(1:2));
            if ~(sample_dist(1) < rect_recover(3) && sample_dist(2) < rect_recover(4))
                try
                    train_data_negative(j,:) = extract_img_sample(img_gray,sample,samples_size(1),samples_size(2));
                    j = j + 1;
                    hold on;
                    plot(sample(1), sample(2), 'r*');
                    hold off;
                catch
                end
            end
        end
        train_data = [train_data_positive; train_data_negative];
        svmStatic = svmtrain(train_data,data_label);
        
        %% recording tracking results
        len = numel(img_dir) - start_frame + 1;
        res = zeros(len,4);
        trackingCenter = zeros(len,2);
        fps = zeros(len-1,1);
        recording_counter = 1;
        res(recording_counter,:) = rect_tracking;
        trackingCenter(recording_counter,:) = pos(1:2);
        
        %% tracking
        
        for frame = start_frame+1:numel(img_dir)        
            img = imread(img_dir(frame).name);
            % record time cost
            tic
            if size(img,3) > 1
                img_gray = rgb2gray(img);
            else
                img_gray = img;
            end

            %% tracking recovery
            if confidence_weight < 0.01
                N_samples = 100;
                xp = zeros(N_samples,2);
                i = 1;
                [ymax,xmax] = size(img_gray);
                ymax = ymax - samples_size(2)/2;
                xmax = xmax - samples_size(1)/2;
                test_data = zeros(N_samples,feature_vector_size);
                while i <= N_samples
                    if rand(1) < 0.2
                        xp(i,:) = pos(1:2) + pos_shift + [randi([0,10]), randi([0,10])];
                    else
                        xp(i,:) = [randi([round(samples_size(1)/2), round(xmax)],1),randi([round(samples_size(2)/2),round(ymax)],1)];
                    end
                    try
                        test_data(i,:) = extract_img_sample(img_gray,xp(i,:),samples_size(1),samples_size(2));
                        i = i + 1;
                    catch
                    end
                end
                classes_static = svmclassify(svmStatic, test_data);
                classS_index = find(classes_static == 1);
                %% recover location
                rect = find_new_pos(xp,classS_index,rect_recover,img_gray,StaticFeatures,ConfidenceFeatures,target_para);
                rect = fix_rect(img_gray, rect);
                svm_shift = rect(1:2) + rect(3:4)./2 - pos(1:2);
                pos(1:2) = pos(1:2) + svm_shift;
                Target_Dictionary.Location(:,1) = Target_Dictionary.Location(:,1) + svm_shift(1);
                Target_Dictionary.Location(:,2) = Target_Dictionary.Location(:,2) + svm_shift(2);
                target_size = StaticSize;
                %% plot
                hold on;
                plot(xp(:,1),xp(:,2),'+y');
                plot(xp(classS_index,1),xp(classS_index,2),'+g');
                rectangle('Position',rect,'LineWidth',1,'EdgeColor','r');
                hold off;
            end
            % local layer appearance modelling
            im_candidate = imcrop(img_gray,rect);
            mincontrast_para = target_para;
            candidate_corners = detectFASTFeatures(im_candidate, 'MinContrast', mincontrast_para);
            mincontrast_para = 0.2;
            while candidate_corners.Count < n && mincontrast_para > 0.05
                mincontrast_para = 0.8*mincontrast_para;
                candidate_corners = detectFASTFeatures(im_candidate, 'MinContrast', mincontrast_para);
            end
            
            candidate_corners.Location = candidate_corners.Location + repmat([rect(1)-1,rect(2)-1],candidate_corners.Count,1);
            
            [Candidate_Features, Candidate_Points] = extractFeatures(img_gray, candidate_corners);
            Candidate_Dictionary.Features = Candidate_Features.Features;
            Candidate_Dictionary.Location = Candidate_Points.Location;
            
            indexPairs = matchFeatures(StaticFeatures, Candidate_Features);
            n_correspoundence = size(indexPairs,1);
            original_matched_number = n_correspoundence;
            
            if original_matched_number < 6
                indexPairs = matchFeatures(ConfidenceFeatures, Candidate_Features);
                n_correspoundence = size(indexPairs,1);
                if n_correspoundence < minimum_trust_n_paris
                    Target_Features = binaryFeatures(Target_Dictionary.Features);
                    indexPairs = matchFeatures(Target_Features, Candidate_Features);
                    n_correspoundence = size(indexPairs,1);
                    reset_flag = 0;
                else
                    Target_Dictionary.Features = ConfidenceFeatures.Features;
                    Target_Dictionary.Location = ConfidencePoint;
                    target_size = ConfidenceSize;
                    ranking = confidence_rank;
                    feature_link_table = eye(size(Target_Dictionary.Features,1));
                    pos = confidence_pos;
                    reset_flag = 1;
                    confidence_update_flag = 1;
                    rect_tracking = rect_tracking_confidence;
                end
            else
                Target_Dictionary.Features = StaticFeatures.Features;
                Target_Dictionary.Location = StaticPoints;
                target_size = StaticSize;
                ranking = static_rank;
                feature_link_table = eye(size(Target_Dictionary.Features,1));
                pos = original_pos;
                reset_flag = 1;
                confidence_update_flag = 1;
                rect_tracking = rect_tracking_static;
            end
            %% weighted ranking shift
            Target_Dictionary_size = size(Target_Dictionary.Location,1);
            matched_target = Target_Dictionary.Location(indexPairs(:,1),:);
            matched_candidate = Candidate_Dictionary.Location(indexPairs(:,2),:);
            consensusPairs = [];
            outlierPair = [];
            Tinliers = [];
            Cinliers = [];
            Toutliers = [];
            Coutliers = [];
            
            shift_weight = ranking(indexPairs(:,1),2)/sum(ranking(indexPairs(:,1),2));
            
            shift_vector = matched_candidate - matched_target;
            pos_shift = sum([shift_weight,shift_weight].*shift_vector,1);
            
            shift_error = sum(abs(shift_vector - repmat(pos_shift,size(shift_vector,1),1)),2);
            shift_error_mu = mean(shift_error);
            shift_error_sigma = std(shift_error);
            
            inlier_index = find(shift_error(shift_error < shift_error_mu));
            if ~isempty(inlier_index)
                Tinliers = indexPairs(inlier_index,1);
                Cinliers = indexPairs(inlier_index,2);
                consensusPairs = [Tinliers,Cinliers];
            else
                search_flag = 1;
            end
            
            outlier_index = find(shift_error(shift_error > shift_error_mu + shift_error_sigma));
            if ~isempty(outlier_index)
                Toutliers = indexPairs(outlier_index,1);
                Coutliers = indexPairs(outlier_index,2);
                outlierPair = [Toutliers,Coutliers];
            end
            %% compute scale
            if size(Tinliers,1) > 20
                inlier_target = Target_Dictionary.Location(Tinliers,:);
                inlier_candidate = Candidate_Dictionary.Location(Cinliers,:);
                
                std_inlier_target = std(inlier_target,1);
                std_inlier_candidate = std(inlier_candidate,1);
                
                new_scale = std_inlier_candidate./std_inlier_target;
            else
                new_scale = [1,1];
            end
            %% target new position and scale
            tform.T = eye(3);
            tform.T(3,1:2) = pos_shift;
            
            if ~reset_flag
                if sum(abs(pos_shift)) < 40
                    previous_tform.T = tform.T;
                else
                    tform.T = previous_tform.T;
                    search_flag = 1;
                end
            end
            
            register_point = [Target_Dictionary.Location, ones(Target_Dictionary_size,1)];
            register_point = register_point*tform.T;
            Target_Dictionary.Location = register_point(:,1:2);
            
            center_location = repmat(pos(1:2),Target_Dictionary_size,1);
            reference_location = Target_Dictionary.Location - center_location;
            reference_location = reference_location.*repmat(new_scale,Target_Dictionary_size,1);
            Target_Dictionary.Location = reference_location + center_location;
            
            new_size = target_size + 0.5*(new_scale - 1).*target_size;
            
            target_size = new_size;
            pos = pos*tform.T;
            
            matching_confidence = sum(ranking(indexPairs(:,1),2))/sum(ranking(:,2));
            try
                confidence_weight = sum(ranking(consensusPairs(:,1),2))/sum(ranking(indexPairs(:,1),2));
            catch
                confidence_weight = 0;
            end
            %% update appearance model
            if confidence_weight > 0.1
                [Target_Dictionary, feature_link_table, ranking] = update_link_dable(feature_link_table, Target_Dictionary, Candidate_Dictionary, indexPairs, consensusPairs, outlierPair, dictionary_maximum_size, confidence_weight);
            end
                       
            if confidence_update_flag || matching_confidence > 0.2 && original_matched_number > 3
                ConfidenceFeatures = binaryFeatures(Target_Dictionary.Features);
                ConfidencePoint = Target_Dictionary.Location;
                ConfidenceSize = target_size;
                confidence_pos = pos;
                confidence_rank = ranking;
                confidence_update_flag = 0;
                rect_tracking_confidence = rect_tracking;
            end
            
            rect = [pos(1:2) - target_size/2, target_size];
            rect(1:2) = rect(1:2) - 0.01*search_flag*target_size;
            rect(3:4) = rect(3:4) + 0.02*search_flag*target_size;
            rect = fix_rect(img,rect);
            search_flag = 0; 
            
            rect_tracking(3:4) = rect_tracking(3:4) + 0.5*(new_scale - 1).*rect_tracking(3:4);
            rect_tracking(1:2) = pos(1:2) - rect_tracking(3:4)/2;
            
            timecost = toc;
            
            %% recording
            fps(recording_counter) = 1/timecost;
            recording_counter = recording_counter + 1;
            res(recording_counter,:) = rect_tracking;
            trackingCenter(recording_counter,:) = pos(1:2);
            
            %% plot
            imshow(img);
            hold on;
            rectangle('Position',rect_tracking,'LineWidth',4,'EdgeColor','g');
            xlabel(['frame = ',num2str(frame), '  time cost = ', num2str(timecost)]);
            hold off;
            drawnow;
            
        end
        %% record our tracking results
        results{1,ex_iter}.fps = mean(fps);
        results{1,ex_iter}.res = res;
        results{1,ex_iter}.trackingCenter = trackingCenter;
        
    end
    %% save results
    result_name = res_dir.name;
    result_name = regexprep(result_name,'Frag','OurMethod');
    save(result_name, 'results');
    
end
