function out = my_voting_system(G,p)

if nargin < 2
    p = 0.85;
end

n = size(G,1);

cj=sum(G,1);% sum of column of G
ci=sum(G,2);

% k = find(cj~=0);
% D = sparse(k,k,1./cj(k),n,n);
D=diag(1./cj);
% k = find(ci~=0);
% B = sparse(k,k,1./ci(k),n,n);
B=diag(1./ci);

A=p*G*D+(1-p)*B*G;

x=ones(n,1);% init vector


% z=zeros(n,1);
cnt=1;% recording the times of iteration
while cnt < n
%     z=x;
    x=A*x;
    cnt=cnt+1;
    x(x < 1) = 1;
end

[x1,index]=sort(x);%ranking the x
x1=flipud(x1);%ranking the rows of x1 from max to min
index=flipud(index);
%out put the result
out=[1:n;x1';index'];

return
